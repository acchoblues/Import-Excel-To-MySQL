<footer class="site-footer">
          <div class="text-center">
              <a href="http://www.hakkoblogs.com" target="_blank">Hakko Bio Richard</a> &copy; 2016 Import Data Excel
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>